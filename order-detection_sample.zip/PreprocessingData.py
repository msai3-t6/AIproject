###### IMPORTS ################
import os
import librosa
import librosa.display
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

#### LOADING THE VOICE DATA FOR VISUALIZATION ###
walley_sample = "data/mini_speech_commands/down/0a9f9af7_nohash_0.wav"
data, sample_rate = librosa.load(walley_sample)
print(data.shape, sample_rate)

##### VISUALIZING MFCC #######
mfccs = librosa.feature.mfcc(y=data, sr=sample_rate, n_mfcc=40)
print("Shape of mfcc:", mfccs.shape)

plt.title("MFCC")
librosa.display.specshow(mfccs, sr=sample_rate, x_axis='time')
plt.show()

##### Doing this for every sample ##

all_data = []
df = {}

data_path_dict = {
    0: ["data/mini_speech_commands/down/" + file_path for file_path in os.listdir("data/mini_speech_commands/down/")],
    1: ["data/mini_speech_commands/go/" + file_path for file_path in os.listdir("data/mini_speech_commands/go/")],
    2: ["data/mini_speech_commands/left/" + file_path for file_path in os.listdir("data/mini_speech_commands/left/")],
    3: ["data/mini_speech_commands/no/" + file_path for file_path in os.listdir("data/mini_speech_commands/no/")],
    4: ["data/mini_speech_commands/right/" + file_path for file_path in os.listdir("data/mini_speech_commands/right/")],
    5: ["data/mini_speech_commands/stop/" + file_path for file_path in os.listdir("data/mini_speech_commands/stop/")],
    6: ["data/mini_speech_commands/up/" + file_path for file_path in os.listdir("data/mini_speech_commands/up/")],
    7: ["data/mini_speech_commands/yes/" + file_path for file_path in os.listdir("data/mini_speech_commands/yes/")]

}

# the background_sound/ directory has all sounds which DOES NOT CONTAIN wake word
# the audio_data/ directory has all sound WHICH HAS Wake word

for class_label, list_of_files in data_path_dict.items():
    for single_file in list_of_files:
        audio, sample_rate = librosa.load(single_file) ## Loading file
        mfcc = librosa.feature.mfcc(y=audio, sr=sample_rate, n_mfcc=40) ## Apllying mfcc
        mfcc_processed = np.mean(mfcc.T, axis=0) ## some pre-processing
        all_data.append([mfcc_processed, class_label])
    print(f"Info: Succesfully Preprocessed Class Label {class_label}")

df = pd.DataFrame(all_data, columns=["feature", "class_label"])
print(df)

###### SAVING FOR FUTURE USE ###
save_dir = 'final_audio_data_csv/'
os.makedirs(save_dir, exist_ok=True)
df.to_pickle("final_audio_data_csv/audio_data.csv")

