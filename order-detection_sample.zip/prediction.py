######## IMPORTS ##########
import sounddevice as sd
from scipy.io.wavfile import write
import librosa
import numpy as np
import os 
from tensorflow.keras.models import load_model

####### ALL CONSTANTS #####
labels  = os.listdir("data/mini_speech_commands/")
filtered_list = [label for label in labels if ".md" not in label]

print(filtered_list)

fs = 44100
seconds = 2
filename = "prediction.wav"
class_names = filtered_list
print(class_names)

##### LOADING OUR SAVED MODEL and PREDICTING ###
model = load_model("saved_model/WWD_ihyun.h5")

print("Prediction Started: ")
i = 0
while True:
    print("Say Now: ")
    myrecording = sd.rec(int(seconds * fs), samplerate=fs, channels=2)
    sd.wait()
    write(filename, fs, myrecording)

    audio, sample_rate = librosa.load(filename)
    mfcc = librosa.feature.mfcc(y=audio, sr=sample_rate, n_mfcc=40)
    mfcc_processed = np.mean(mfcc.T, axis=0)


    prediction = model.predict(np.expand_dims(mfcc_processed, axis=0))
    predicted_index = np.argmax(prediction[0])

    if prediction[0, predicted_index] > 0.95:  # confidence가 0.95 이상인 경우만 출력
        print(f"'{class_names[predicted_index]}' 단어가 검출되었습니다({i})")
